---
title: OcanPredict
emoji: 💻
colorFrom: red
colorTo: blue
sdk: docker
pinned: false
short_description: reserved
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference